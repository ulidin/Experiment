class ShoppingListItem {
    constructor(name = '', amount = 1, added = false) {
        this.name   = name;
        this.amount = amount;
        this.added  = added;
    }
}
